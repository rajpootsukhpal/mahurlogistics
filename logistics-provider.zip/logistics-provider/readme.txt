=== Logistics Provider ===
Contributors: ThemesPride
Tags: wide-blocks, block-styles, one-column, two-columns, right-sidebar, left-sidebar, three-columns, four-columns, grid-layout, custom-colors, custom-header, custom-background, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, featured-image-header, full-width-template, rtl-language-support, translation-ready, sticky-post, theme-options, post-formats, threaded-comments, flexible-header, portfolio, e-commerce, blog
Requires at least: 5.0
Tested up to: 6.8
Requires PHP: 5.6
Stable tag: 0.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

The Logistics Provider Theme is a powerful, modern, and fully responsive solution crafted for logistics companies, freight service providers, and supply chain management firms. It supports a diverse range of operations including transportation logistics, warehouse logistics, Shipping Logistics, Truckload Services, Supply Solutions, Logistics Hub, Last Mile Delivery, Domestic Shipping and inventory logistics. Whether you manage a freight forwarding company, offer international logistics services, or specialize in last mile delivery and courier logistics, this theme provides a professional and adaptable platform to promote your logistics solutions. It is also suitable for third-party logistics (3PL), cold chain logistics, and express delivery service providers looking to enhance their digital presence. Visually, the theme boasts a clean, sleek, and corporate aesthetic designed to establish trust and credibility with clients. It includes interactive sections for order tracking, logistics service listings, fleet information, shipment status, and real-time logistics updates. Advanced features such as logistics tracking, route optimization, and real-time shipment monitoring enhance user experience and operational transparency. Integration-ready design allows you to embed logistics software tools, contact forms, and booking systems with ease. Built with optimized, secure, and clean code, the theme delivers fast page load speeds and is mobile-friendly and retina-ready for perfect display across all devices. Customization options and translation readiness ensure this theme is scalable for logistics providers of all sizes and specialties. The theme can create a some of the best website for delivery management, cargo shipping, fleet tracking, fulfillment services, transport company, moving services, transport tracking, haulage services, and logistics business. For seamless contact and service inquiries, the theme works efficiently with the Contact Form 7 plugin to capture client details and service requests. Demo Link: https://page.themespride.com/logistics-provider-pro/

Installation

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in Logistics Provider in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
4. Go to # for a guide on how to customize this theme.

== Changelog ==

= 0.1 =
    * Initial version released.

= 0.2 =
    * Added get started.
    * Added footer link.
    * Added demo import.

= 0.3 =
    * Added "Pro" link in the relevant section.
    * Improved styling for the "Get Started" button.
    * Adjusted footer heading font size for 768px screen width.
    * Added time meta display on the blog post page.
    * Added show/hide setting for the slider title.
    * Added show/hide setting for the slider content.
    * Added documentation link in customizer.

= 0.4 =
    * Added option to set slider height.
    * Added responsive slider height settings.
    * Added option to show/hide slider overlay opacity.
    * Added option to set background color for slider overlay opacity.
    * Added slider opacity option.

= 0.5 =
    * Updated theme content.

= 0.6 =
    * Added option to set banner content length.
    * Resolved error related to the responsive footer widget.
    * Added option to show/hide capital letters on the blog page.
    * Added zoom effect on menu item hover.
    * Added banner advertisement in the dashboard.

= 0.7 =
    * Resolved theme css errors.

= 0.8 =   
    * Resolved theme css errors.

== Resources ==

Logistics Provider Theme, Copyright 2025 ThemesPride
Logistics Provider is distributed under the terms of the GNU GPL

Logistics Provider Theme is derived from Twenty Seventeen WordPress Theme, Copyright 2016 WordPress.org
Twenty Seventeen is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Logistics Provider bundles the following third-party resources:

CSS bootstrap.css
License: bootstrap is licensed under the MIT License
https://github.com/twbs/bootstrap/blob/master/LICENSE
Source: https://getbootstrap.com/

JS bootstrap.js
License: bootstrap is licensed under the MIT License
https://github.com/twbs/bootstrap/blob/master/LICENSE
Source: https://getbootstrap.com/

Font Awesome icons, Copyright Dave Gandy
License: Icons: CC BY 4.0 License (https://creativecommons.org/licenses/by/4.0/)
https://github.com/FortAwesome/Font-Awesome/blob/6.x/LICENSE.txt
Source: https://fontawesome.com/icons

Owl Carousel v2.3.4 Copyright 2013-2018 David Deutsch
Licensed under: SEE LICENSE IN
https://github.com/OwlCarousel2/OwlCarousel2/blob/master/LICENSE
Source: https://owlcarousel2.github.io/OwlCarousel2/

Webfont-Loader
License: https://github.com/WPTT/webfont-loader/blob/master/LICENSE
Source: https://github.com/WPTT/webfont-loader

TGMPA, GaryJones Copyright (C) 1989, 1991
License: GNU General Public License v2.0
Source: https://github.com/TGMPA/TGM-Plugin-Activation/blob/develop/LICENSE.md

Google Fonts : 
Montserrat 
    License: [Google Fonts Licensing](https://fonts.google.com/knowledge/glossary/licensing)  
    Source: [Montserrat on Google Fonts](https://fonts.google.com/specimen/Montserrat)  

Pxhere Images
Source: https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Url: https://pxhere.com/en/license

Pxhere Image
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/673217

Pxhere Image
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1232592

Pxhere Image
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1367679

Pxhere Image
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/668790

Pxhere Image
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/77605